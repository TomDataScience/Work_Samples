CREATE TABLE users (
	usersID int NOT NULL AUTO_INCREMENT,
    UsersName varchar(50) NOT NULL,
    UsersPassword varchar(50) NOT NULL,
    PRIMARY KEY(usersID));
    
INSERT INTO users VALUES(null,'Test name','testpassword');

SELECT * FROM users;

UPDATE users 
SET usersname = 'Melanie Rice' 
WHERE usersname = 'Test name';

DELETE FROM users
WHERE usersID = 2;    